﻿using System.ComponentModel.DataAnnotations;

namespace ContactManagement.Core
{
    public class Contact 
    {
        public int Id { get; set; }

        [Required, StringLength(80)]
        public string FirstName { get; set; }

        [Required, StringLength(80)]
        public string LastName { get; set; }

        [Required, StringLength(10)]
        public string PhoneNumber { get; set; }

        [Required, StringLength(255)]
        public string Location { get; set; }

        [Required, StringLength(255)]
        public string EmailId { get; set; }
        public Status Status { get; set; }
    }
}
