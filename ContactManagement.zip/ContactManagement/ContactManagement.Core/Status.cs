﻿namespace ContactManagement.Core
{
    public enum Status
    {
        Active,
        Inactive
    }
}
