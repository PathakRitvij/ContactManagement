﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ContactManagement.Core;

namespace ContactManagement.Data
{
    public class ContactManagementDbContext : DbContext
    {
        public ContactManagementDbContext(DbContextOptions<ContactManagementDbContext> options)
            : base(options)
        {
                
        }

        public DbSet<Contact> Contacts { get; set; }
    }
}
