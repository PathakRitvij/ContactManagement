﻿using ContactManagement.Core;
using System.Collections.Generic;


namespace ContactManagement.Data
{
    public interface IContactData
    {
        IEnumerable<Contact> GetContactsByName(string name);
        Contact GetById(int id);
        Contact Update(Contact updatedContact);
        Contact Add(Contact newContact);
        Contact Delete(int id);
        int GetCountOfContacts();
        int Commit();
    }  
}
