﻿using System.Linq;
using ContactManagement.Core;
using System.Collections.Generic;


namespace ContactManagement.Data
{
    public class InMemoryContactData : IContactData
    {
        readonly List<Contact> Contacts;

        public InMemoryContactData()
        {
            Contacts = new List<Contact>()
            {
                new Contact { Id = 1, FirstName = "Ritvij", LastName = "Pathak", Location="Pune", Status=Status.Active, PhoneNumber ="72384682"},
                new Contact { Id = 2, FirstName = "Sandip", LastName = "Daware", Location="Kolkata", Status=Status.Active, PhoneNumber ="72384645"},
                new Contact { Id = 3, FirstName = "Sunil", LastName = "Gujar", Location="Hydrabad", Status=Status.Active,PhoneNumber = "72384629" },
            };
        }

        public Contact GetById(int id)
        {
            return Contacts.SingleOrDefault(r => r.Id == id);
        }

        public Contact Add(Contact newContact)
        {
            Contacts.Add(newContact);
            newContact.Id = Contacts.Max(r => r.Id) + 1;
            return newContact;
        }

        public Contact Update(Contact updatedContact)
        {
            var Contact = Contacts.SingleOrDefault(r => r.Id == updatedContact.Id);
            if(Contact != null)
            {
                Contact.FirstName = updatedContact.FirstName;
                Contact.LastName = updatedContact.LastName;
                Contact.PhoneNumber = updatedContact.PhoneNumber;
                Contact.Location = updatedContact.Location;
                Contact.Status = updatedContact.Status;
                Contact.EmailId = updatedContact.EmailId;


            }
            return Contact;
        }

        public int Commit()
        {
            return 0;
        }

        public IEnumerable<Contact> GetContactsByName(string name = null)
        {
            return from r in Contacts
                   where string.IsNullOrEmpty(name) || r.FirstName.StartsWith(name)
                   orderby r.FirstName
                   select r;
        }

        public Contact Delete(int id)
        {
            var Contact = Contacts.FirstOrDefault(r => r.Id == id);
            if(Contact != null)
            {
                Contacts.Remove(Contact);
            }
            return null;
        }

        public int GetCountOfContacts()
        {
            return Contacts.Count();
        }
    }
}
