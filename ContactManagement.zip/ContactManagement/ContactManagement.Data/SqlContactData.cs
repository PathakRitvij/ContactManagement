﻿using System.Collections.Generic;
using ContactManagement.Core;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ContactManagement.Data
{
    public class SqlContactData : IContactData
    {
        private readonly ContactManagementDbContext db;

        public SqlContactData(ContactManagementDbContext db)
        {
            this.db = db;
        }

        public Contact Add(Contact newContact)
        {
            db.Add(newContact);
            return newContact;
        }

        public int Commit()
        {
            return db.SaveChanges();
        }

        public Contact Delete(int id)
        {
            var Contact = GetById(id);
            if(Contact != null)
            {
                db.Contacts.Remove(Contact);
            }
            return Contact;
        }

        public Contact GetById(int id)
        {
            return db.Contacts.Find(id);
        }

        public int GetCountOfContacts()
        {
            return db.Contacts.Count();
        }

        public IEnumerable<Contact> GetContactsByName(string name)
        {
            var query = from r in db.Contacts
                        where r.FirstName.StartsWith(name) || string.IsNullOrEmpty(name)
                        orderby r.FirstName
                        select r;
            return query;
        }

        public Contact Update(Contact updatedContact)
        {
            var entity = db.Contacts.Attach(updatedContact);
            entity.State = EntityState.Modified;
            return updatedContact;
        }
    }
}
