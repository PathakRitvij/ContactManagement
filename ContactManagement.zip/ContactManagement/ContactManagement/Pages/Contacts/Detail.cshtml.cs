﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ContactManagement.Core;
using ContactManagement.Data;

namespace ContactManagement.Pages.Contacts
{
    public class DetailModel : PageModel
    {
        private readonly IContactData ContactData;

        [TempData]
        public string Message { get; set; }

        public Contact Contact { get; set; }

        public DetailModel(IContactData ContactData)
        {
            this.ContactData = ContactData;
        }

        public IActionResult OnGet(int ContactId)
        {
            Contact = ContactData.GetById(ContactId);
            if(Contact == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }
    }
}