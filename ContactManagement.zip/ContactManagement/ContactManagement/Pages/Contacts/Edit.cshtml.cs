﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ContactManagement.Core;
using ContactManagement.Data;

namespace ContactManagement.Pages.Contacts
{
    public class EditModel : PageModel
    {
        private readonly IContactData ContactData;
        private readonly IHtmlHelper htmlHelper;

        [BindProperty]
        public Contact Contact { get; set; }
        public IEnumerable<SelectListItem> Status { get; set; }

        public EditModel(IContactData ContactData,
                         IHtmlHelper htmlHelper)
        {
            this.ContactData = ContactData;
            this.htmlHelper = htmlHelper;
        }

        public IActionResult OnGet(int? ContactId)
        {
            Status = htmlHelper.GetEnumSelectList<Status>();
            if (ContactId.HasValue)
            {
                Contact = ContactData.GetById(ContactId.Value);
            }
            else
            {
                Contact = new Contact();
            }
            if(Contact == null)
            {
                return RedirectToPage("./NotFound");
            }
            return Page();
        }

        public IActionResult OnPost()
        {               
            if(!ModelState.IsValid)
            {
                Status = htmlHelper.GetEnumSelectList<Status>();
                return Page();                
            }

            if (Contact.Id > 0)
            {
                ContactData.Update(Contact);
            }
            else
            {
                ContactData.Add(Contact);
            }
            ContactData.Commit();
            TempData["Message"] = "Contact saved!";
            return RedirectToPage("./Detail", new { ContactId = Contact.Id });
        }
    }
}