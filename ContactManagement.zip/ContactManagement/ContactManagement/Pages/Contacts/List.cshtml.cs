using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ContactManagement.Core;
using ContactManagement.Data;

namespace ContactManagement.Pages.Contacts
{
    public class ListModel : PageModel
    {
        private readonly IConfiguration config;
        private readonly IContactData ContactData;
        private readonly ILogger<ListModel> logger;

        public string Message { get; set; }
        public IEnumerable<Contact> Contacts { get; set; }

        [BindProperty(SupportsGet =true)]
        public string SearchTerm { get; set; }

        public ListModel(IConfiguration config, 
                         IContactData ContactData,
                         ILogger<ListModel> logger)
        {
            this.config = config;
            this.ContactData = ContactData;
            this.logger = logger;
        }

        public void OnGet()
        {
            logger.LogError("Executing ListModel");
            Message = config["Message"];
            Contacts = ContactData.GetContactsByName(SearchTerm);
        }
    }
}